# Setup (one page)

You will test how well Oracle's FSCR sets up one module, the same way we tested Common Features, Procurement and
Sourcing and Supplier Management. Claude does the work; you sign in and check.

## 1. What you need

| Item | Detail |
|---|---|
| **Claude Desktop** | Installed and signed in to your GoSaaS Claude account. You will use its **Code** tab. |
| **Model** | **Opus 5.5**. Pick it in the model menu before you start. |
| **Python** | **3.10 or newer** (3.11 or 3.12 recommended). Check with `python --version` (Mac: `python3 --version`). If it is missing, install it from python.org and tick "Add Python to PATH". No extra packages are needed. |
| **Browser** | Microsoft Edge or Google Chrome (used for the sign-in page and to draw the 4 table images). |
| **Oracle access** | Your **own** login to the Oracle Fusion **test** environment (release 26D or later), with the roles in "Your Oracle account" below. Never production. |
| **Sign-in values file** | **Abdullah sends each person a separate file**, `fscr-signin-values.txt`. It holds the values for `core/auth/fusionEnv.properties` (environment name, Fusion URL, Client ID, scope, redirect) and step-by-step sign-in help. The values are **not in this pack on purpose**. Save the file **outside** the pack folder (for example in Documents), never put it in a zip, Drive evidence or chat, and tell Claude only its path. Your Oracle user name and password are not in it: you type them only on Oracle's sign-in page. |
| **Node.js / git** | Not needed. |

### Your Oracle account (ask your Oracle admin before you start)

| You need | Why |
|---|---|
| A user of your own in the test environment (no shared logins) | Every record and Run Book is made in your name. |
| The job role **Application Implementation Consultant** (FSCR's own minimum for setup work) | Setup tasks, setup data export and import (FSM CSV), and Run Books. |
| Data access to any business unit your tasks use (for example Pricing Administrator on a test BU) | Without it Oracle says the business unit "isn't valid" (seen in Run 01). |
| Rights for your module's setup tasks | Some modules need extra setup privileges; if Oracle says "not authorized" for one task only, ask for that task's privilege. |
| Upload rights to the FSM import folder (UCM account `setup/functionalSetupManager/import`) | The Data Loader puts each file there before the import. |
| Access to the FSCR sign-in app | One Client ID serves everyone; you do **not** need your own. Only if the admin has set the app to "assigned users only" must they add you to it. |

If something is missing you will see one of these, and the fix is always the admin, not a new sign-in:
- Oracle's sign-in page says you are not allowed to use the application: ask the admin to add you to the FSCR sign-in app.
- `The authenticated Fusion user does not have permission to upload files to the UCM account ...`: ask for upload rights (above).
- An HTTP **403** (forbidden) from an export, the Data Loader or a Run Book step after a good sign-in: a role is missing. Signing in again does not help.

## 2. Unzip and open

1. Download `fscr-module-test-pack.zip` from Drive. If it comes in parts, put all parts in one folder and unzip the first part.
2. Unzip it to a short path, for example `C:\fscr-module-test-pack` (Mac: your Documents folder).
3. Open Claude Desktop → **Code** tab → choose the folder `fscr-module-test-pack`.

## 3. Sign in with your own login

Say to Claude: **"Help me set up my Oracle sign-in. The values are in <full path of fscr-signin-values.txt>."**
Claude copies the values into `core/auth/fusionEnv.properties` without showing them, then starts the sign-in. A browser
window opens. **You** type your Oracle user name and password there. Never paste them into the chat.

On the first sign-in on a computer, FSCR asks once for the Fusion URL, environment name and Client ID to create its
trust file (`~/.fusionaim/oauth-trust.json`); Claude passes the same values from your values file. This question is
expected. Your values file says what to do if the browser or Windows asks you to trust anything else. If your browser is
already signed in to Oracle, the window may close by itself and the sign-in still completes.

**Windows:** before Claude runs any FSCR script it sets `PYTHONUTF8=1` (FSCR's status reports print symbols that the
Windows console cannot show otherwise).

## 4. Start the test

Say exactly (with your module and initials):

> **Test the module Procurement, my initials are AB**

Module names are the tracker rows, for example `General Ledger`, `Payables`, `Global HR` or `Inventory Management`.
Claude can list them all.

## 5. What Claude produces

In `evidence/<Module>/` (about 30–90 minutes):
- `RESULT.md`: verdict, plan, Run Book, 6-task table, scores with reasons, time taken
- `tracker_row.md`: your tracker values, ready to paste
- `plan.csv`, `oracle_links.csv`, `data/`, `INDEX.md`
- `images/`: 4 table pictures (coverage, plan result, 6 tasks, tracker row)

In Oracle: only records named `FSCRT_<your initials>_...`. Nothing existing is changed.

## 6. Hand it in

1. Upload the whole `evidence/<Module>` folder to Google Drive.
2. Share it with Abdullah (Viewer) and **send him the folder link**.
3. Do **not** edit the tracker. It is view only, and Abdullah pastes your `tracker_row.md`.

Optional: open a **new** Claude chat on the same folder and say "verify the module <name>" for an independent check.

## If something goes wrong

| Problem | What to do |
|---|---|
| Sign-in fails with a network timeout | Try once more. It usually works the second time. |
| Sign-in says the values or client "must match" / "not enrolled" | Copy the values file again exactly; your values file lists each message and its fix. |
| "Not authorized", HTTP 403, or no upload permission after a good sign-in | A role is missing in your Oracle account: see "Your Oracle account" above and ask your Oracle admin. |
| Run Book "create" timed out or says "unknown" | Do **not** create it again. Claude checks later by name and links it by hand. |
| "Payment terms object order mismatch" (Receivables only) | Use the optional patch in `module-test-kit/patches/`. Read its README first. |
| Import fails: the CSV needs an internal ID | Expected for some tasks. Claude stops after 2 tries and marks it Not done. |
| A task needs a Procurement (or other) business unit | Claude may create a new `FSCRT_` test BU, never change an existing one. Otherwise it is marked Not done. |
| Oracle has no CSV or API for a task | Normal. It is screen-only work and is not counted against FSCR. |
| Oracle rejects a value (for example INDEPENDENT) | Claude uses Oracle's code instead (INDEP). |
| `UnicodeEncodeError` from an FSCR script (Windows) | Set `PYTHONUTF8=1` and run it again. |
| `python` not found | Install Python 3.12 from python.org with "Add Python to PATH", then restart Claude Desktop. |
| No images made / "No Edge or Chrome found" | Install Edge or Chrome. |
| A check says FAIL | Ask Claude to fix the listed problem and run the check again. |
