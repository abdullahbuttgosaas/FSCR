# Changes

## Pack v3 (17/11/2026): sign-in values outside the pack

| # | Change | Where |
|---:|---|---|
| 1 | Sign-in values (environment name, Fusion URL, Client ID, scope, redirect) now come from a separate file, `fscr-signin-values.txt`, that Abdullah shares with each person. It is never part of the pack; SETUP.md and the playbook say to keep it outside the pack, zips, evidence and chat. The pack still contains no sign-in value (scanned). Added "Your Oracle account": the roles needed (Application Implementation Consultant, module setup privileges, FSM import upload rights), that one Client ID serves everyone, when an admin must add a person to the sign-in app, and the messages a person sees when something is missing, with the fix. New troubleshooting rows. | `SETUP.md` §1, §3, "If something goes wrong"; `module-test-kit/PLAYBOOK.md` Step 0; `PACK_VERSION.txt` |

No official FSCR file and no kit script changed in v3.

## Pack v2 (17/11/2026): fixes from the cold test (Run 38)

A new person tested the pack with nothing else (module PLM - Quality Management, initials TC, ETIA-TEST) and an
independent check ran `verify.md` on the result. Every problem they hit is fixed below. **No official FSCR file was
changed in v2**: all fixes are in the added files (`SETUP.md`, `CLAUDE.md`, `module-test-kit/`).

| # | Problem a new person hit | Fix | Where |
|---:|---|---|---|
| 1 | The pack never said which sign-in values are needed (environment name, Fusion URL, Client ID, exact scope) or that the redirect is fixed. | Listed the 4 values, where to get them, the fixed redirect, the trust prompt, and "keep them in a local file, not chat". | `SETUP.md` §1, §3; `PLAYBOOK.md` Step 0 |
| 2 | FSCR scripts crash on Windows with `UnicodeEncodeError` (status tables print symbols). | Set `PYTHONUTF8=1` before FSCR scripts. | `SETUP.md`, `CLAUDE.md`, `PLAYBOOK.md` Folders, `prompts/module_test.md` |
| 3 | Step 2a gave no commands: building FSCR's project needed a task-mapping file, a resolver sequence and 3 FSCR skills read from source. | New `scripts/fscr_project_input.py` (plan.csv → the 2 files FSCR needs) and the exact initializer and planning commands. | `PLAYBOOK.md` Step 2a; `scripts/fscr_project_input.py` |
| 4 | FSCR rejects a project ID like `FSCRT_AB_Module`. | Project ID is lowercase-hyphen (`fscrt-ab-<module>`); the project **name** keeps `FSCRT_AB_<Module>`. | `PLAYBOOK.md` Step 2a |
| 5 | A quote with a comma, written unquoted in `links_input.csv`, was silently cut and still "passed". | `plan_builder.py`/`link_checker.py` now stop on a row with extra fields; the playbook says to quote every quote. | `scripts/kitlib.py` (`read_links_csv`), `link_checker.py`, `plan_builder.py`; `PLAYBOOK.md` 2c |
| 6 | A wrong Oracle URL saves the Help Center landing page without an error. | Playbook: open each saved page; delete a landing page and find the right one. | `PLAYBOOK.md` 2c |
| 7 | Step 3: the Run Book name comes from the project name (no name option), `--project-root` must be absolute, `runID` was not set after create, and the read-back command was missing. | Exact create, name check, `runID` and `list-tasks` commands; `runbook_create.json` summary for the evidence. | `PLAYBOOK.md` Step 3 |
| 8 | Step 4 gave no commands for the CSV route: export, package, Task Hook preview/approve/verify, approved upload, status, read-back (5 FSCR skills had to be read). | A 7-step recipe with every command. | `PLAYBOOK.md` Step 4 |
| 9 | Loading Oracle's full export would re-send every existing record (FSM import merges by key). | New `scripts/fsm_package.py`: keeps only rows holding your `FSCRT_` prefix; every other CSV header-only. | `scripts/fsm_package.py`; `PLAYBOOK.md` Step 4 |
| 10 | The six-task rule gives only 2 tasks for a module with one group (PLM - Quality Management: 0/5/0). | Fill-up rule: up to 4 loadable tasks (or all), max 6, labelled `Fill-up:`. | `PLAYBOOK.md` Step 4; `prompts/module_test.md`; `prompts/verify.md` 7 |
| 11 | `make_images.py` accepts only the 3 group names, so a fill-up could not be labelled in the group column; the image title said "Six" over 5 rows. | Label goes in `record_or_reason`; title now "Sample tasks ... N of up to 6". | `PLAYBOOK.md` Step 4; `scripts/make_images.py` |
| 12 | The Data Loader asks for approval before each upload; the pack did not say whether "Test the module" approves it. | It approves validated packages holding only `FSCRT_<XX>_` records; anything else needs a yes in chat. | `PLAYBOOK.md` Step 4; `prompts/module_test.md` |
| 13 | Task Hook returned `skipped` (no FSCR rules for the task); the pack did not say what to record. | Record `not_applicable`, never "passed"; a skipped hook never supports an Execution 5. | `PLAYBOOK.md` Step 4 and Step 5 |
| 14 | A task export timed out while polling. | Resume with `--process-id`; never start a second export. | `PLAYBOOK.md` Step 4 |
| 15 | FSCR's status check writes logs to the home folder (`~/.codex/...`) unless told otherwise. | Always pass `--diagnostic-log-output-dir work/<Module>/load/status_logs`. | `PLAYBOOK.md` Step 4 |
| 16 | The evidence folder had no read-back proof: the independent check could not trace request numbers, and "513 existing rows" double-counted tasks that share one export (266 distinct). Each load also has two request numbers (Data Loader and Oracle's FSM import). | New `scripts/readback_compare.py` writes `readback.csv`, `readback_summary.json` (distinct rows, changed = 0) and `load_log.csv` (both request numbers, rows processed/failed); `build_evidence.py` copies them and fails if a Done task has none. | `scripts/readback_compare.py`, `scripts/build_evidence.py`; `PLAYBOOK.md` Step 4; `templates/RESULT.md` |
| 17 | `--names "Name,login"` puts a person's name in the command line and the chat transcript. | All kit scripts accept `--names @<file>`. | `scripts/kitlib.py` (`parse_names`), `build_evidence.py`, `make_images.py`, `secret_scan.py`, `tracker_row.py`; `PLAYBOOK.md` Step 7; `CLAUDE.md` |
| 18 | A sign-in name split into words gave a false secret-scan hit on Oracle's own text. | Playbook: whole names only. | `PLAYBOOK.md` Step 7 |
| 19 | Task exports and FSM logs contain other people's user names. | Never copied to `evidence/`; deleted at clean-up. | `PLAYBOOK.md` Step 4 and Step 8 |
| 20 | Script `--help` examples used `work/Procurement` (pack-root paths) while the playbook runs scripts from `scripts/` with `../../`. | All `--help` examples now use `../../work/...`; the playbook says where each kind of script runs from. | 7 scripts' help text; `PLAYBOOK.md` Folders |
| 21 | Scoring: the tester first gave Execution 4 and Fit Low; the independent check showed the playbook's rules point to 3 and Medium. | Clarified: hand-built CSVs with no FSCR recipe = manual fix (3); coverage None alone is not Fit Low. | `PLAYBOOK.md` Step 5 |
| 22 | `verify.md`: no folder to run from, Step 2 lacked `--module`/`--scope`, Step 3 had nothing to re-run, image footers incomplete, no rule when the checker has no names file. | Fixed all five and added read-back and fill-up checks. | `prompts/verify.md` |
| 23 | The second independent check found no Task Hook proof in the evidence, and the upload had used up the saved envelopes. | Save the `build-data-load-preview` output as `tN_task_hook_preview.json`; `readback_compare.py --load-dir` writes `task_hook.csv` (statuses as FSCR recorded them); `build_evidence.py` requires it for a Done task. | `PLAYBOOK.md` Step 4; `scripts/readback_compare.py`, `scripts/build_evidence.py`; `prompts/verify.md` 9 |
| 24 | `prefix_rows_after_total` added up tasks that share one export package (32 for 17 real rows). | Now `prefix_rows_after_distinct`. | `scripts/readback_compare.py` |
| 25 | Oracle's "rows processed" (top-level objects) did not match the new rows read back (child and translation rows), and the result wording mixed them. | Playbook: quote both, each as what it is; `load_log.csv` help says what Oracle counts. | `PLAYBOOK.md` Step 4; `scripts/readback_compare.py` |
| 26 | `build_evidence.py` only checked that files existed. | It now fails if a `FSCRT_` code or request number in `six_tasks.csv` is not in `readback.csv`/`load_log.csv`, if an existing row changed, or if there are more than 6 sample tasks. | `scripts/build_evidence.py`; `PLAYBOOK.md` Step 4 |
| 27 | The Finish time was written before rework, so evidence files were newer than it; `verify.md` step 6 used a path that does not exist from `scripts/`; clean-up deletions were not checked. | Finish time includes rework and `build_evidence.py` runs last; step 6 path fixed; step 9 checks deletions, file times, INDEX hashes and `task_hook.csv`. | `PLAYBOOK.md` Step 8; `prompts/verify.md` 6, 9 |

### Example rows updated to `module_counts.csv`

| Example | Total Tasks | Missing | What changed |
|---|---:|---|---|
| Common Features | 227 | 148/227 | `tracker_row.md` scope/plan bullets; note at the top of `RESULT.md`; `images/01_coverage.png` and `images/08_tracker_row.png` rebuilt from the scope map |
| Procurement | 41 | 26/41 | same; `RESULT.md` Missing line (was 39/60); `images/01_procurement_coverage.png` replaced by `images/01_coverage.png`; `images/05_tracker_row_values.png` rebuilt |
| Sourcing and Supplier Management | 58 | 26/58 | same; `RESULT.md` Missing line (was 46/91); `images/01_coverage.png` and `images/04_tracker_row_values.png` rebuilt |

The plan, Run Book and six-task figures in each example (144, 60 and 91 planned tasks) and their images are those runs'
own measurements on the older scope. They are kept as found and labelled so in each RESULT.md and `examples/README.md`.

### Not fixed (cannot be fixed inside the pack)

- The 4 sign-in values for a test environment cannot ship in the pack; each person must get them from an admin.
- FSCR has no skill, guide or Task Hook rule for the PLM - Quality Management tasks; that is an FSCR gap for GoSaaS, not a pack fix.

### Build checks (v2)

- All kit scripts compile and were re-run on the cold-test data: counts "match", plan numbers unchanged, a bad quote now stops the run, `--names @file` works, `readback_compare.py` writes `task_hook.csv` and 17 distinct new rows, `build_evidence.py` PASS with the new consistency checks.
- The added files and `module-test-kit/` scan clean with `secret_scan.py` (tokens, passwords, user names, e-mail, machine paths, Oracle hosts).

---

## Pack v1: changes compared with the official FSCR repository

Official repository: https://github.com/oracle/fscr, commit `2801695703b909891753790b60a694d2b270724e` (see PACK_VERSION.txt).

## 1. Settings that point at an existing Run Book (step 0b)

Every tracked settings file (`.properties`, `.yaml`, `.json` configs) was searched for a Run Book ID, run ID or
journey ID with a value.

| File | Setting | Official value | Value in this pack | Change |
|---|---|---|---|---|
| `core/data-loader/config/env.properties` | `runID` | empty | empty | none needed |

No other tracked setting points at a Run Book. **No FSCR file was changed.** All 6,087 FSCR files are
byte-identical to the commit. Before every load, still check that `runID` is empty or holds **your own** Run Book.
Never load into someone else's Run Book.

## 2. How this pack differs from the copy we tested with

Our working copy, unpacked on 28/10/2026, differed from the commit in exactly these 3 files. The pack ships the
**official originals** of all 3:

| File | Our working copy | In this pack |
|---|---|---|
| `pillars/erp/financials/customer-billing/manage-receivables-payment-terms/scripts/payment_terms_fsm_package.py` | patched on 28/10/2026 (fixed object-order check removed) | official original. The patch is optional, in `module-test-kit/patches/` |
| `core/auth/fusionEnv.properties` | filled in with our environment, Client ID and scopes | official template (placeholders, empty scopes). Each person fills in their own |
| `core/data-loader/config/env.properties` | `runID` set to one of our Run Books | official original (`runID` empty) |

The comparison was done file by file on git blob hashes: 6,087 tracked files, 3 different, 0 missing.
The working copy also had files git does not track (2 `__pycache__` folders and a draft project folder).
None of them were copied.

## 3. Files added on top of the repository

- `CLAUDE.md`: what the pack is, the rules, and what to do on "test module X"
- `SETUP.md`: one-page setup for a new person
- `README_PACK.md`: three lines. It is not named `README.md`, so the official FSCR `README.md` stays untouched
- `PACK_VERSION.txt`, `CHANGES.md`: this file
- `module-test-kit/`: playbook, scripts, prompts, tracker guide, scope map, examples, optional patch

## 4. Build checks

- The kit and the added files scan clean with `secret_scan.py`. Nothing in them points to folders outside the pack.
- The official FSCR files are byte-identical to the commit, so nothing was removed from them. The scanner does flag
  Oracle's own content: code that handles tokens, a password prompt, Oracle help-site links, a placeholder e-mail,
  and 3 machine paths of Oracle's authors (2 under `pillars/hcm/*/best-practice-rules/*/source-integrity.json`,
  1 in `pillars/hcm/hcm-tool/approval-rules/configure-rules/ora-resource/ora_reference_lookups.md`).
  These are public in oracle/fscr and contain nothing of ours.
- Scripts tested on Run 35 (Purchasing) data: the plan numbers match that run (3 of 4 sourced links in order,
  2 of 4 unverified out of order).

## Build time log

| Start | Finish | Minutes |
|---|---|---:|
| 17/11/2026 16:05 | 17/11/2026 16:35 | 30 |

The start is approximate: it is when the build was approved after the git question, before the clone at 16:08.
