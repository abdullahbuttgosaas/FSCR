"""Step 4 helper - read-back proof. Compares the task exports taken before and after your loads, and reads Oracle's
FSM import logs, so every number in six_tasks.csv and RESULT.md has a file behind it in the evidence folder.

Usage (from module-test-kit/scripts):
  python readback_compare.py --before ../../work/<Module>/export_before --after ../../work/<Module>/export_after \
      --prefix FSCRT_AB_ --loads ../../work/<Module>/load/load_requests.csv \
      --logs ../../work/<Module>/load/status_logs --out ../../work/<Module>

--before/--after: one sub-folder per task code holding that task's export ZIP(s) (newest is used).
--loads: CSV you write as you load: data_set,task_code,data_loader_request_id (the RequestId the Data Loader prints).
--logs: folder given to get_data_load_info.py --diagnostic-log-output-dir.
Writes (only codes and counts; no user names, no other columns):
  readback.csv          per task and CSV: rows with your prefix before / after, and their keys
  load_log.csv          per load: data set, Data Loader request, Oracle FSM import request, status, and the rows Oracle's
                        log counts (Oracle counts top-level objects; child rows such as translations are not counted)
  task_hook.csv         per load (if --load-dir holds tN_task_hook_preview.json or *_task_validation_envelope.json): task, Task Hook rule sources and
                        statuses as FSCR recorded them
  readback_summary.json existing rows checked (distinct: tasks that share one package are counted once) and how many
                        changed or went missing (must be 0)
Local files only. No sign-in, no network.
"""
from __future__ import annotations

import argparse
import csv
import io
import json
import re
import zipfile

from kitlib import Path, read_csv, write_csv


def newest_zip(folder: Path) -> Path | None:
    zs = sorted(folder.glob("*.zip"), key=lambda p: p.stat().st_mtime)
    return zs[-1] if zs else None


def tables(zp: Path) -> dict[str, list[list[str]]]:
    z = zipfile.ZipFile(zp)
    return {n: list(csv.reader(io.StringIO(z.read(n).decode("utf-8-sig"))))
            for n in z.namelist() if n.endswith(".csv")}


def main() -> int:
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--before", type=Path, required=True)
    ap.add_argument("--after", type=Path, required=True)
    ap.add_argument("--prefix", required=True)
    ap.add_argument("--loads", type=Path)
    ap.add_argument("--logs", type=Path)
    ap.add_argument("--load-dir", type=Path, help="folder with the tN_task_validation_envelope.json files")
    ap.add_argument("--out", type=Path, required=True)
    a = ap.parse_args()
    rb, existing, changed, new_rows = [], set(), set(), set()
    for tdir in sorted(p for p in a.after.iterdir() if p.is_dir()):
        za, zb = newest_zip(tdir), newest_zip(a.before / tdir.name)
        if not za or not zb:
            continue
        ta, tb = tables(za), tables(zb)
        for n, rows_b in tb.items():
            after = {tuple(r) for r in ta.get(n, [])[1:]}
            for r in rows_b[1:]:
                key = (n, tuple(r))
                existing.add(key)
                if tuple(r) not in after:
                    changed.add(key)
            hits = lambda rows: [r for r in rows[1:] if any(a.prefix in v for v in r)]
            ha, hb = hits(ta.get(n, [[]])), hits(rows_b)
            new_rows.update((n, tuple(r)) for r in ha)
            keys = sorted({v for r in ha for v in r if v.startswith(a.prefix)})
            rb.append({"task_code": tdir.name, "csv_file": n, "prefix_rows_before": len(hb),
                       "prefix_rows_after": len(ha), "record_keys": "; ".join(keys)})
    write_csv(a.out / "readback.csv", rb, ["task_code", "csv_file", "prefix_rows_before", "prefix_rows_after",
                                          "record_keys"])
    summary = {"prefix": a.prefix, "existing_rows_distinct": len(existing), "existing_changed_or_missing": len(changed),
               "prefix_rows_before_total": sum(r["prefix_rows_before"] for r in rb),
               "prefix_rows_after_distinct": len(new_rows),
               "note": "distinct = tasks that share one export package are counted once"}
    (a.out / "readback_summary.json").write_text(json.dumps(summary, indent=1), encoding="utf-8")
    loads = read_csv(a.loads) if a.loads and a.loads.is_file() else []
    ll = []
    for row in loads:
        rec = {"data_set": row["data_set"], "task_code": row["task_code"],
               "data_loader_request_id": row["data_loader_request_id"], "fsm_import_request_id": "",
               "status": "", "rows_processed": "", "rows_failed": ""}
        logs = sorted(a.logs.glob(f"{row['data_set']}-fsm-*.log")) if a.logs else []
        if logs:
            t = logs[-1].read_text(encoding="utf-8", errors="replace")
            m = re.search(r"Request ID:\s*([\d,]+)", t)
            rec["fsm_import_request_id"] = m.group(1).replace(",", "") if m else ""
            st = re.findall(r"Business object: [^.]+\. Status: ([^.]+)\.", t)
            rec["status"] = "; ".join(sorted(set(st)))
            rec["rows_processed"] = sum(int(x) for x in re.findall(r"A total of (\d+) rows were processed", t))
            rec["rows_failed"] = sum(int(x) for x in re.findall(r"(\d+) rows of them failed", t))
        ll.append(rec)
    if ll:
        write_csv(a.out / "load_log.csv", ll, list(ll[0]))
    th = []
    found = sorted(a.load_dir.glob("*_task_hook_preview.json")) if a.load_dir else []
    for env in found or (sorted(a.load_dir.glob("*_task_validation_envelope.json")) if a.load_dir else []):
        d = json.loads(env.read_text(encoding="utf-8"))
        pv = d.get("preview", d)
        for r in pv.get("ruleResults", []):
            th.append({"envelope": env.name, "task_code": pv.get("taskCode", ""), "task_name": pv.get("taskName", ""),
                       "rule_source": r.get("source", ""), "status": r.get("status", ""),
                       "note": "; ".join(i.get("message", "") for i in r.get("issues", []))})
    if th:
        write_csv(a.out / "task_hook.csv", th, list(th[0]))
    print(f"read-back: {summary['prefix_rows_before_total']} {a.prefix} rows before, "
          f"{summary['prefix_rows_after_distinct']} distinct after; existing rows {summary['existing_rows_distinct']} distinct, "
          f"{summary['existing_changed_or_missing']} changed or missing; {len(ll)} load(s) logged")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
