"""Step 2a helper - FSCR project input. Turn plan.csv (the resolver method's order) into the two files FSCR's project
initializer needs, so nobody has to hand-write them.

Usage (from module-test-kit/scripts, after plan_builder.py):
  python fscr_project_input.py --plan ../../work/Procurement/plan.csv --out ../../work/Procurement/fscr_project_input --pillar SCM

Writes into --out:
  identified-task-mapping.json   pass to initialize_project_workspace.py --identified-task-mapping
  setup-task-sequence.json       copy to project/<id>/artifacts/shared/implementation-planning/task-dependency-resolver/current/
Each task keeps its catalog offering, functional area and display sequence; "Resolver Sequence" is plan.csv's seq.
Read only. No sign-in, no network.
"""
from __future__ import annotations

import argparse
import json

from kitlib import Path, read_csv


def main() -> int:
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--plan", type=Path, required=True, help="plan.csv from plan_builder.py")
    ap.add_argument("--out", type=Path, required=True)
    ap.add_argument("--pillar", required=True, choices=["ERP", "HCM", "SCM", "CX"], help="pillar from coverage.csv")
    a = ap.parse_args()
    rows = read_csv(a.plan)
    seq, mapping = [], []
    for r in rows:
        n = int(r["seq"])
        seq.append({"sequence": n, "task_code": r["task_code"], "task_name": r["task_name"],
                    "offering": r["catalog_offering"], "functional_area": r["catalog_functional_area"],
                    "catalog_display_sequence": r["catalog_display_sequence"], "sequence_source": "release_catalog",
                    "depends_on": [x for x in (r.get("fscr_prerequisites_found") or "").split(";") if x]})
        mapping.append({"ID": f"T{n:03d}", "Source Task Name": r["task_name"], "Offering": r["catalog_offering"],
                        "Functional Area": r["catalog_functional_area"], "Pillar": a.pillar, "Phase": "build",
                        "Resolver Sequence": n, "Data Paths": [],
                        "Source Reference": f"plan.csv seq {n} ({r['task_code']})"})
    a.out.mkdir(parents=True, exist_ok=True)
    (a.out / "setup-task-sequence.json").write_text(json.dumps(
        {"artifact_type": "setup_task_sequence",
         "method": "shared.implementation-planning.task-dependency-resolver (release catalog order)",
         "setup_task_sequence": seq}, indent=1), encoding="utf-8")
    (a.out / "identified-task-mapping.json").write_text(json.dumps({"source": "plan.csv", "tasks": mapping}, indent=1),
                                                         encoding="utf-8")
    print(f"{len(mapping)} tasks written to {a.out}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
