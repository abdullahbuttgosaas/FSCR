"""Step 4 helper - FSM CSV package with only your new records. Copies Oracle's task-level export package and keeps
ONLY the rows you give; every other CSV keeps its header and no rows. An FSM import merges rows by key, so loading the
full export would re-send (and could change) existing records. This script prevents that.

Usage (from module-test-kit/scripts):
  python fsm_package.py --export <task export .zip> --rows ../../work/<Module>/load/t1_rows.json \
      --prefix FSCRT_AB_ --out ../../work/<Module>/load/FSCRT_AB_t1.zip

rows JSON: {"<CSV file name in the package>": [{"<column>": "<value>", ...}, ...], ...}
Columns must exist in that CSV's header. Every row must contain --prefix in at least one value, or nothing is written.
Read only on Oracle: it only writes a local ZIP. Load the ZIP through FSCR's Data Loader (PLAYBOOK step 4).
"""
from __future__ import annotations

import argparse
import csv
import io
import json
import sys
import zipfile

from kitlib import Path


def main() -> int:
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--export", type=Path, required=True)
    ap.add_argument("--rows", type=Path, required=True)
    ap.add_argument("--prefix", required=True, help="your FSCRT_<initials>_ prefix")
    ap.add_argument("--out", type=Path, required=True)
    a = ap.parse_args()
    if not a.prefix.startswith("FSCRT_"):
        sys.exit("--prefix must start with FSCRT_")
    rows = json.loads(a.rows.read_text(encoding="utf-8"))
    zi = zipfile.ZipFile(a.export)
    names = set(zi.namelist())
    if "ASM_SETUP_CSV_METADATA.xml" not in names:
        sys.exit("not an FSM CSV package (ASM_SETUP_CSV_METADATA.xml missing)")
    for n, rs in rows.items():
        if n not in names:
            sys.exit(f"{n} is not in the package. CSVs: {sorted(x for x in names if x.endswith('.csv'))}")
        for r in rs:
            if not any(a.prefix in str(v) for v in r.values()):
                sys.exit(f"{n}: a row has no value with {a.prefix}; only new test records may be loaded")
    a.out.parent.mkdir(parents=True, exist_ok=True)
    with zipfile.ZipFile(a.out, "w", zipfile.ZIP_DEFLATED) as zo:
        for n in zi.namelist():
            data = zi.read(n)
            if n.endswith(".csv"):
                hdr = next(csv.reader(io.StringIO(data.decode("utf-8-sig"))))
                buf = io.StringIO()
                w = csv.writer(buf, lineterminator="\r\n")
                w.writerow(hdr)
                for r in rows.get(n, []):
                    bad = set(r) - set(hdr)
                    if bad:
                        sys.exit(f"{n}: unknown columns {sorted(bad)}")
                    w.writerow([r.get(h, "") for h in hdr])
                data = buf.getvalue().encode("utf-8")
            zo.writestr(n, data)
    print(f"wrote {a.out.name}: " + ", ".join(f"{k} {len(v)} row(s)" for k, v in rows.items()) +
          "; all other CSVs header only")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
