# Prompt: independent check of a finished module run

Give this to a **new** Claude chat (Opus 5.5) opened on this pack's folder. It must not have run the test itself.
Replace `{MODULE}` with the module name. The check only reads files: it never signs in to Oracle and never changes
the evidence.

---

Check the finished FSCR module test in `evidence/{MODULE}/` independently. Read only: do not sign in to Oracle, and do not
change any file in `evidence/`. Put any helper output in `work/verify_{MODULE}/`. Use the scripts in
`module-test-kit/scripts/` and the rules in `module-test-kit/PLAYBOOK.md` and `module-test-kit/SHEET_FILL_GUIDE.md`.
Run the scripts from `module-test-kit/scripts`, so the paths below start with `../../` (for example
`../../evidence/{MODULE}`). On Windows set `PYTHONUTF8=1`. Quote paths: module names can contain spaces.

1. **Counts.** Run `scope_filter.py --module "{MODULE}" --out "../../work/verify_{MODULE}"`. Compare Total Tasks, Missing (N/total),
   a/b/c and the proposed coverage with `tracker_row.md`, `RESULT.md` and `data/coverage.csv`. Every number must match.
2. **Plan.** Run `plan_builder.py --module "{MODULE}" --scope "../../work/verify_{MODULE}/scope_tasks.csv" --out "../../work/verify_{MODULE}" --links "../../evidence/{MODULE}/data/links_input.csv" --docs "../../evidence/{MODULE}/data/oracle_docs"`
   (the scope file from check 1, the links and saved pages from the evidence). The (a), (b) and (c) numbers must equal those in `RESULT.md` and `data/plan_summary.json`.
   Every link with status `sourced` must pass the quote check. A link presented as verified without a URL and a quote that
   passes is a FAIL.
3. **Run Book.** Compare `RESULT.md` with `data/runbook_summary.json` (steps, route, manual, manual with CSV, prerequisites,
   links in order) and with `data/runbook_step_check.csv` and `data/runbook_tasks_oracle_clean.json` (step order equals
   `plan.csv`). There is nothing to re-run here: `runbook-plan.json` is not part of the evidence. Check
   `data/runbook_create.json`: `create_calls` is 1 (or the timeout is explained), and its ID is the one in RESULT.md.
   Owner or validation-step fields must not be used as criteria.
4. **Scores.** For each of Plan accuracy, Runbook quality and Execution & validation, quote the Guide's 1/3/5 wording
   from the playbook and say whether the score and its reason fit it. Check the Fit rating and FSCR coverage against
   their Guide meanings. Execution must not count tasks that have no CSV or API in Oracle.
5. **Images.** Open each of the 4 PNGs in `images/`. Check that every number and value in them equals the source files
   named in its footer (01: `coverage.csv`, `coverage_by_area.csv`; 02: `plan_summary.json`, `runbook_summary.json`,
   `oracle_links.csv`; 03: `six_tasks.csv`; 04: `tracker_row.md`).
   No more than 4 images. No tokens, user names, e-mail or environment addresses visible.
6. **Tracker row.** Run `tracker_row.py check "../../evidence/{MODULE}/tracker_row.md"`. It must PASS (formats: Missing N/total,
   dates dd/mm/yyyy, Status Completed, bullets, no owners in the gap column).
7. **Known mistakes.** Flag any of these:
   - a Run Book create that was resent after a timeout (two Run Books for one run);
   - a REST object load attempted when the Data Loader can't load it, with no switch to the FSM CSV package;
   - more than 2 tries at an import that needs an internal ID column;
   - Task Hook rule results with no real check behind them;
   - an existing business unit (or any existing record) edited or deleted, or a record not named `FSCRT_<initials>_`;
   - a task with no CSV or API in Oracle counted against FSCR;
   - owner or validation-step fields used as criteria;
   - an unsourced dependency presented as verified;
   - a Done task without read-back proof: every record and request number in `six_tasks.csv` and RESULT.md must be in
     `data/readback.csv` and `data/load_log.csv`, `data/readback_summary.json` must show `existing_changed_or_missing` 0,
     and the "existing rows unchanged" number must equal `existing_rows_distinct`;
   - fill-up tasks not labelled as such (`record_or_reason` starts with `Fill-up:`), or more than 6 sample tasks.
8. **Secrets.** Run `secret_scan.py "../../evidence/{MODULE}"`. It must find nothing. If the person gave you a names
   file, add `--names @<file>`; if not, say in the report that names were not checked by word, only by pattern.
9. **Time and clean-up.** `RESULT.md` has the Start/Finish/Minutes table and says all processes were stopped and that
   `export_before/`, `export_after/` and `load/status_logs/` were deleted. No evidence file is newer than the Finish
   time (the evidence is built last). Every SHA-256 in `INDEX.md` matches its file. `data/task_hook.csv` holds the Task
   Hook result for every load (statuses as FSCR recorded them; `not_applicable` is never "passed").

Report **PASS** or **FAIL** at the top, then a table: check, result, reason (with file and number). List every
mistake found. Finally, stop any process you started and confirm nothing is left running.
